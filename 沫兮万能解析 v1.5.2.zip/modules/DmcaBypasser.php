<?php
/**
 * DMCA规避模块
 */

class DmcaBypasser {
    /**
     * 设置cURL基本选项
     * @param resource $ch cURL句柄
     * @param string $url 请求URL
     */
    public static function setCurlOptions($ch, $url) {
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, REQUEST_TIMEOUT);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_ENCODING, ''); // 自动处理压缩
    }
    
    /**
     * 设置DMCA规避选项
     * @param resource $ch cURL句柄
     * @param string $url 请求URL
     */
    public static function setBypassOptions($ch, $url) {
        if (!BYPASS_DMCA) {
            return;
        }
        
        // 随机User-Agent
        if (RANDOM_USER_AGENT) {
            $userAgents = [
                'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
                'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.1.1 Safari/605.1.15',
                'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:89.0) Gecko/20100101 Firefox/89.0',
                'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.107 Safari/537.36'
            ];
            curl_setopt($ch, CURLOPT_USERAGENT, $userAgents[array_rand($userAgents)]);
        }
        
        // 设置Referer策略
        if (REFERER_STRATEGY) {
            $urlParts = parse_url($url);
            if (isset($urlParts['host'])) {
                $referer = $urlParts['scheme'] . '://' . $urlParts['host'] . '/';
                curl_setopt($ch, CURLOPT_REFERER, $referer);
            }
        }
        
        // 设置其他规避选项
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language: en-US,en;q=0.5',
            'Connection: keep-alive',
            'Upgrade-Insecure-Requests: 1',
            'Cache-Control: max-age=0'
        ]);
    }
    
    /**
     * 检测DMCA错误
     * @param array $response API响应数据
     * @return bool 是否包含DMCA错误
     */
    public static function hasDmcaError($response) {
        if (!is_array($response)) {
            return false;
        }
        
        // DMCA错误关键词（多语言）
        $dmcaKeywords = [
            'dmca', '违反', 'verstößt', '移除', '删除', '削除', '제거',
            'copyright', '版权', 'urheberrecht', '著作権', '저작권',
            'not available', '不可用', 'nicht verfügbar', '利用不可', '사용 불가'
        ];
        
        // 检查响应中是否包含DMCA关键词
        foreach ($response as $key => $value) {
            if (is_string($value)) {
                $lowerValue = strtolower($value);
                foreach ($dmcaKeywords as $keyword) {
                    if (strpos($lowerValue, strtolower($keyword)) !== false) {
                        return true;
                    }
                }
            }
        }
        
        return false;
    }
    
    /**
     * 下载文件内容
     * @param string $url 文件URL
     * @return string|bool 文件内容或false
     */
    public static function downloadFile($url) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 15); // 减少超时时间
        curl_setopt($ch, CURLOPT_ENCODING, ''); // 自动处理压缩
        curl_setopt($ch, CURLOPT_NOSIGNAL, 1); // 更精确的超时控制
        
        // 设置DMCA规避选项
        self::setBypassOptions($ch, $url);
        
        $fileContent = curl_exec($ch);
        
        if (curl_errno($ch)) {
            if (DEBUG_MODE) {
                error_log("下载错误: " . curl_error($ch) . " URL: " . $url);
            }
            curl_close($ch);
            return false;
        }
        
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        return ($httpCode >= 200 && $httpCode < 300) ? $fileContent : false;
    }
}