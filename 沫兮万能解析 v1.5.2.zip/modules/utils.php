<?php
/**
 * 工具函数模块
 */

/**
 * 格式化文件大小
 * @param int $bytes 字节数
 * @return string 格式化后的文件大小
 */
function format_file_size($bytes) {
    if ($bytes >= 1073741824) {
        return number_format($bytes / 1073741824, 2) . ' GB';
    } elseif ($bytes >= 1048576) {
        return number_format($bytes / 1048576, 2) . ' MB';
    } elseif ($bytes >= 1024) {
        return number_format($bytes / 1024, 2) . ' KB';
    } else {
        return $bytes . ' B';
    }
}

/**
 * 获取当前完整 URL 路径
 * @return string 当前URL
 */
function get_current_url() {
    $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https://' : 'http://';
    $host = $_SERVER['HTTP_HOST'];
    $scriptPath = dirname($_SERVER['SCRIPT_NAME']); // 获取脚本所在目录
    return $protocol . $host . rtrim($scriptPath, '/') . '/';
}