<?php
/**
 * 缓存管理模块
 */

class CacheManager {
    /**
     * 初始化缓存目录
     */
    public static function initCacheDir() {
        if (CACHE_ENABLED && !file_exists(CACHE_PATH)) {
            if (!mkdir(CACHE_PATH, 0777, true)) {
                // 如果创建缓存目录失败，记录错误
                if (DEBUG_MODE) {
                    error_log("无法创建缓存目录: " . CACHE_PATH);
                }
            }
        }
    }
    
    /**
     * 检查缓存是否存在且未过期
     * @param string $targetUrl 目标URL
     * @return array|bool 缓存信息数组或false
     */
    public static function checkCache($targetUrl) {
        if (!CACHE_ENABLED || !DOWNLOAD_ENABLED) {
            return false;
        }
        
        $cacheFileName = md5($targetUrl) . '.m3u8'; // 缓存文件名，使用 .m3u8 后缀
        $cacheFile = CACHE_PATH . $cacheFileName; // 缓存文件路径
        
        // 检查缓存是否存在且未过期
        if (file_exists($cacheFile) && !self::isCacheExpired($cacheFile)) {
            require_once 'modules/utils.php';
            
            $msg = SHOW_URL_IN_MSG ? get_current_url() . $cacheFile : '缓存调用数据正常';
            
            return [
                'code' => 200,
                'msg' => $msg,
                'url' => get_current_url() . $cacheFile, // 当前域名 + 缓存文件路径
                'get_url' => $targetUrl, 
                'cache_time' => date('Y-m-d H:i:s', filemtime($cacheFile)), // 缓存时间
                'file_size' => format_file_size(filesize($cacheFile)), // 文件大小
                'download_msg' => '使用缓存文件' // 下载状态消息
            ];
        }
        
        return false;
    }
    
    /**
     * 检查缓存是否过期
     * @param string $cacheFile 缓存文件路径
     * @return bool 是否过期
     */
    private static function isCacheExpired($cacheFile) {
        $cacheTime = filemtime($cacheFile);
        return (time() - $cacheTime) > CACHE_EXPIRE;
    }
    
    /**
     * 保存缓存
     * @param string $targetUrl 目标URL
     * @param string $data 要缓存的数据
     * @return string|bool 缓存文件路径或false
     */
    public static function saveCache($targetUrl, $data) {
        if (!CACHE_ENABLED || !DOWNLOAD_ENABLED) {
            return false;
        }
        
        $cacheFileName = md5($targetUrl) . '.m3u8';
        $cacheFile = CACHE_PATH . $cacheFileName;
        
        return file_put_contents($cacheFile, $data) !== false ? $cacheFile : false;
    }
}