<?php
/**
 * IP授权验证模块
 */

class IPAuthorizer {
    /**
     * 验证IP是否授权
     * @return bool|array 验证通过返回true，失败返回错误响应数组
     */
    public static function validate() {
        if (!IP_AUTH_ENABLED) {
            return true; // IP授权未启用，直接通过
        }
        
        // 读取IP授权列表文件
        $authorizedIps = [];
        if (file_exists(IP_AUTH_FILE)) {
            $authorizedIps = file(IP_AUTH_FILE, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
            // 过滤空行和注释行
            $authorizedIps = array_filter($authorizedIps, function($ip) {
                $ip = trim($ip);
                return !empty($ip) && $ip[0] !== '#'; // 忽略以#开头的注释行
            });
        }
        
        // 自动获取当前域名的服务器IP地址
        $domain = $_SERVER['HTTP_HOST']; // 获取当前域名
        $serverIp = gethostbyname($domain); // 通过域名解析获取服务器IP地址
        
        // 将服务器IP添加到授权列表
        if (!in_array($serverIp, $authorizedIps)) {
            $authorizedIps[] = $serverIp;
        }

        // 获取客户端IP
        $clientIp = (string)$_SERVER["REMOTE_ADDR"]; // 直接访问IP
        $forwardedIp = isset($_SERVER["HTTP_X_FORWARDED_FOR"]) ? (string)$_SERVER["HTTP_X_FORWARDED_FOR"] : ''; // 代理IP
        
        // 检查 IP 是否授权
        $ipAuthorized = in_array($clientIp, $authorizedIps) || 
                       (!empty($forwardedIp) && in_array($forwardedIp, $authorizedIps));

        if (!$ipAuthorized) {
            return self::getErrorResponse($clientIp, $forwardedIp, $authorizedIps);
        }
        
        return true;
    }
    
    /**
     * 获取IP验证失败的响应
     * @param string $clientIp 客户端IP
     * @param string $forwardedIp 代理IP
     * @param array $authorizedIps 授权IP列表
     * @return array 错误响应数组
     */
    private static function getErrorResponse($clientIp, $forwardedIp, $authorizedIps) {
        $response = [
            'code' => 403,
            'msg' => 'IP未授权',
            'client_ip' => $clientIp,
            'forwarded_ip' => $forwardedIp,
            'ip_auth_enabled' => true,
            'ip_auth_file' => IP_AUTH_FILE,
            'authorized_ips_count' => count($authorizedIps)
        ];
        
        // 调试模式下显示更多信息
        if (DEBUG_MODE) {
            $domain = $_SERVER['HTTP_HOST'];
            $response['server_ip'] = gethostbyname($domain);
            $response['authorized_ips'] = $authorizedIps;
        }
        
        return $response;
    }
}