<?php
/**
 * 响应构建模块
 */

class ResponseBuilder {
    /**
     * 构建成功响应
     * @param string $returnUrl 返回的URL
     * @param string $parsedUrl 解析的URL
     * @param string $targetUrl 目标URL
     * @param string $downloadMsg 下载消息
     * @param string|null $usedApi 使用的API
     * @param string|null $cacheFile 缓存文件路径
     * @return array 响应数组
     */
    public static function buildSuccessResponse($returnUrl, $parsedUrl, $targetUrl, $downloadMsg, $usedApi = null, $cacheFile = null) {
        require_once 'modules/utils.php';
        
        $msg = SHOW_URL_IN_MSG ? $returnUrl : '解析成功';
        
        $response = [
            'code' => 200,
            'msg' => $msg,
            'url' => $returnUrl,
            'form_url' => $parsedUrl,
            'get_url' => $targetUrl,
            'cache_time' => date('Y-m-d H:i:s', time()),
            'download_msg' => $downloadMsg
        ];
        
        // 如果需要显示API源，添加到响应中
        if (SHOW_API_SOURCE && $usedApi) {
            $response['api_source'] = $usedApi;
        }
        
        // 如果文件存在且下载功能启用，添加文件大小信息
        if (DOWNLOAD_ENABLED && CACHE_ENABLED && $cacheFile && file_exists($cacheFile)) {
            $response['file_size'] = format_file_size(filesize($cacheFile));
        }
        
        // 调试模式下添加更多信息
        if (DEBUG_MODE) {
            $response['debug'] = [
                'cache_enabled' => CACHE_ENABLED,
                'download_enabled' => DOWNLOAD_ENABLED,
                'show_api_source' => SHOW_API_SOURCE,
                'ip_auth_enabled' => IP_AUTH_ENABLED,
                'used_api' => $usedApi,
                'show_url_in_msg' => SHOW_URL_IN_MSG,
                'concurrent_requests' => CONCURRENT_REQUESTS,
                'request_timeout' => REQUEST_TIMEOUT,
                'bypass_dmca' => BYPASS_DMCA,
                'use_proxy' => USE_PROXY
            ];
        }
        
        return $response;
    }
    
    /**
     * 构建错误响应
     * @param string $message 错误消息
     * @param int $code 错误代码
     * @param array $additionalData 附加数据
     * @return array 错误响应数组
     */
    public static function buildErrorResponse($message, $code = 500, $additionalData = []) {
        $response = [
            'code' => $code,
            'msg' => $message
        ];
        
        if (!empty($additionalData)) {
            $response = array_merge($response, $additionalData);
        }
        
        return $response;
    }
}