<?php
/**
 * API健康检查模块 - 定期检查API接口的可用性
 */

class ApiHealthChecker {
    
    // 健康检查结果文件
    private static $healthCheckFile = 'logs/api_health.json';
    
    /**
     * 执行API健康检查
     * @param array $apiList API列表
     * @param array $proxyList 代理列表
     * @return array 健康检查结果
     */
    public static function checkAllApis($apiList, $proxyList = []) {
        $results = [];
        $testUrl = 'https://v.qq.com/x/cover/7s9z55p1fq2qzzk.html'; // 测试用的标准视频URL
        
        foreach ($apiList as $api) {
            $results[$api] = self::checkApi($api, $testUrl, $proxyList);
        }
        
        // 保存检查结果
        self::saveHealthCheckResults($results);
        
        return $results;
    }
    
    /**
     * 检查单个API
     * @param string $api API地址
     * @param string $testUrl 测试URL
     * @param array $proxyList 代理列表
     * @return array 检查结果
     */
    public static function checkApi($api, $testUrl, $proxyList = []) {
        $startTime = microtime(true);
        $urlWithParams = $api . urlencode($testUrl);
        
        $ch = curl_init();
        
        // 设置基本cURL选项
        DmcaBypasser::setCurlOptions($ch, $urlWithParams);
        
        // 设置DMCA规避选项
        DmcaBypasser::setBypassOptions($ch, $testUrl);
        
        // 设置代理（如果启用）
        if (USE_PROXY && !empty($proxyList)) {
            $proxy = $proxyList[array_rand($proxyList)];
            curl_setopt($ch, CURLOPT_PROXY, $proxy);
        }
        
        // 设置超时时间较短，用于健康检查
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError = curl_error($ch);
        $totalTime = microtime(true) - $startTime;
        
        curl_close($ch);
        
        // 评估API健康状况
        $isHealthy = false;
        $reason = '';
        
        if ($curlError) {
            $reason = "cURL错误: $curlError";
        } elseif ($httpCode !== 200) {
            $reason = "HTTP状态码: $httpCode";
        } else {
            // 尝试解析JSON
            $decodedResponse = json_decode($response, true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                $reason = "JSON解析失败: " . json_last_error_msg();
            } elseif (DmcaBypasser::hasDmcaError($decodedResponse)) {
                $reason = "DMCA错误";
            } else {
                // 检查是否有URL字段
                $possibleFields = ['url', 'm3u8', 'play_url', 'src', 'address'];
                foreach ($possibleFields as $field) {
                    if (isset($decodedResponse[$field]) && !empty($decodedResponse[$field])) {
                        $isHealthy = true;
                        break;
                    }
                }
                
                if (!$isHealthy) {
                    $reason = "响应中未找到有效URL字段";
                }
            }
        }
        
        return [
            'healthy' => $isHealthy,
            'response_time' => round($totalTime, 3),
            'http_code' => $httpCode,
            'error' => $curlError,
            'reason' => $reason,
            'last_checked' => date('Y-m-d H:i:s')
        ];
    }
    
    /**
     * 保存健康检查结果
     * @param array $results 健康检查结果
     */
    private static function saveHealthCheckResults($results) {
        // 创建日志目录
        if (!file_exists('logs')) {
            mkdir('logs', 0777, true);
        }
        
        // 添加时间戳
        $data = [
            'check_time' => date('Y-m-d H:i:s'),
            'results' => $results
        ];
        
        file_put_contents(self::$healthCheckFile, json_encode($data, JSON_PRETTY_PRINT));
    }
    
    /**
     * 获取健康检查结果
     * @return array 健康检查结果
     */
    public static function getHealthCheckResults() {
        if (file_exists(self::$healthCheckFile)) {
            return json_decode(file_get_contents(self::$healthCheckFile), true) ?: [];
        }
        return [];
    }
    
    /**
     * 获取可用的API列表
     * @param array $apiList 原始API列表
     * @return array 可用的API列表
     */
    public static function getHealthyApis($apiList) {
        $results = self::getHealthCheckResults();
        $healthyApis = [];
        
        if (!empty($results['results'])) {
            foreach ($results['results'] as $api => $result) {
                if ($result['healthy'] && in_array($api, $apiList)) {
                    $healthyApis[] = $api;
                }
            }
        }
        
        // 如果没有健康检查结果或所有API都不健康，返回原始列表
        return !empty($healthyApis) ? $healthyApis : $apiList;
    }
    
    /**
     * 自动禁用不可用的API
     * @param array $apiList 原始API列表
     * @return array 过滤后的API列表
     */
    public static function filterUnhealthyApis($apiList) {
        // 只有在配置了健康检查时才过滤
        if (!defined('HEALTH_CHECK_ENABLED') || !HEALTH_CHECK_ENABLED) {
            return $apiList;
        }
        
        return self::getHealthyApis($apiList);
    }
    
    /**
     * 获取API健康报告
     * @return string 健康报告HTML
     */
    public static function getHealthReport() {
        $results = self::getHealthCheckResults();
        $report = "<h2>API健康检查报告</h2>";
        $report .= "<p>检查时间: " . ($results['check_time'] ?? '从未检查') . "</p>";
        
        if (!empty($results['results'])) {
            $report .= "<table border='1' cellpadding='8' style='border-collapse: collapse;'>";
            $report .= "<tr><th>API</th><th>状态</th><th>响应时间</th><th>最后检查</th><th>详情</th></tr>";
            
            foreach ($results['results'] as $api => $result) {
                $status = $result['healthy'] ? 
                    "<span style='color: green;'>健康</span>" : 
                    "<span style='color: red;'>异常</span>";
                
                $responseTime = $result['response_time'] . " 秒";
                $lastChecked = $result['last_checked'];
                $details = $result['healthy'] ? "正常" : $result['reason'];
                
                $report .= "<tr>
                    <td>" . htmlspecialchars($api) . "</td>
                    <td>$status</td>
                    <td>$responseTime</td>
                    <td>$lastChecked</td>
                    <td>$details</td>
                </tr>";
            }
            
            $report .= "</table>";
        } else {
            $report .= "<p>暂无健康检查数据</p>";
        }
        
        return $report;
    }
}