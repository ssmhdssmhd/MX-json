<?php
/**
 * API加载器模块
 */

class ApiLoader {
    /**
     * 从文件加载API列表
     * @return array API列表数组
     */
    public static function loadApiList() {
        $apiList = [];
        
        if (!file_exists(API_LIST_FILE)) {
            return ['https://openapi.973973.xyz/open/api_free/index?url='];
        }
        
        $content = file_get_contents(API_LIST_FILE);
        // 尝试解析JSON格式（如果文件是JSON数组格式）
        $jsonArray = json_decode($content, true);
        if (json_last_error() === JSON_ERROR_NONE && is_array($jsonArray)) {
            $apiList = $jsonArray;
        } else {
            // 如果不是JSON格式，按行读取
            $lines = file(API_LIST_FILE, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
            // 处理可能的一行多个接口的情况（用逗号分隔）
            foreach ($lines as $line) {
                $line = trim($line);
                // 跳过注释行
                if (empty($line) || $line[0] === '#') {
                    continue;
                }
                // 检查是否包含多个接口（用逗号分隔）
                if (strpos($line, ',') !== false) {
                    $apis = array_map('trim', explode(',', $line));
                    $apiList = array_merge($apiList, $apis);
                } else {
                    $apiList[] = $line;
                }
            }
        }
        
        // 过滤空值和注释
        $apiList = array_filter($apiList, function($api) {
            $api = trim($api);
            return !empty($api) && $api[0] !== '#'; // 忽略以#开头的注释行
        });
        
        // 移除可能重复的接口
        $apiList = array_unique($apiList);
        
        // 如果没有接口，使用默认接口
        if (empty($apiList)) {
            $apiList = ['https://openapi.973973.xyz/open/api_free/index?url='];
        }
        
        return $apiList;
    }
    
    /**
     * 加载代理列表
     * @return array 代理列表数组
     */
    public static function loadProxyList() {
        $proxyList = [];
        
        if (USE_PROXY && file_exists(PROXY_LIST)) {
            $proxyList = file(PROXY_LIST, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
            $proxyList = array_filter($proxyList, function($proxy) {
                $proxy = trim($proxy);
                return !empty($proxy) && $proxy[0] !== '#'; // 忽略以#开头的注释行
            });
        }
        
        return $proxyList;
    }
}