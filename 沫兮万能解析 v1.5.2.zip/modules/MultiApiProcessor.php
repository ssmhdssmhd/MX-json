<?php
/**
 * 多接口处理器模块 - 负责依次尝试多个API接口并记录调试信息
 */

class MultiApiProcessor {
    
    /**
     * 执行多接口请求并返回结果
     * @param array $apiList API列表
     * @param array $proxyList 代理列表
     * @param string $targetUrl 目标URL
     * @return array [使用的API, 解析的URL, API响应, 调试信息]
     */
    public static function process($apiList, $proxyList, $targetUrl) {
        $debugInfo = [];
        $usedApi = null;
        $parsedUrl = null;
        $apiResponse = null;
        
        // 尝试每个API接口
        foreach ($apiList as $index => $api) {
            $result = self::trySingleApi($api, $proxyList, $targetUrl);
            $debugInfo[] = $result['debug'];
            
            // 如果此接口成功，记录结果并跳出循环
            if ($result['success']) {
                $usedApi = $api;
                $parsedUrl = $result['parsed_url'];
                $apiResponse = $result['response'];
                break;
            }
        }
        
        return [$usedApi, $parsedUrl, $apiResponse, $debugInfo];
    }
    
    /**
     * 尝试单个API接口
     * @param string $api API地址
     * @param array $proxyList 代理列表
     * @param string $targetUrl 目标URL
     * @return array 包含结果和调试信息的数组
     */
    private static function trySingleApi($api, $proxyList, $targetUrl) {
        $urlWithParams = $api . urlencode($targetUrl);
        $ch = curl_init();
        
        // 设置基本cURL选项
        DmcaBypasser::setCurlOptions($ch, $urlWithParams);
        
        // 设置DMCA规避选项
        DmcaBypasser::setBypassOptions($ch, $targetUrl);
        
        // 设置代理（如果启用）
        if (USE_PROXY && !empty($proxyList)) {
            $proxy = $proxyList[array_rand($proxyList)];
            curl_setopt($ch, CURLOPT_PROXY, $proxy);
        }
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError = curl_error($ch);
        curl_close($ch);
        
        // 准备调试信息
        $debugInfo = [
            'api' => $api,
            'http_code' => $httpCode,
            'curl_error' => $curlError,
            'success' => false,
            'message' => ''
        ];
        
        // 检查HTTP状态码和cURL错误
        if ($curlError || $httpCode != 200) {
            $debugInfo['message'] = "请求失败: HTTP {$httpCode}, cURL错误: {$curlError}";
            return ['success' => false, 'debug' => $debugInfo];
        }

        // 尝试解析JSON
        $decodedResponse = json_decode($response, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            $debugInfo['message'] = "JSON解析失败: " . json_last_error_msg();
            return ['success' => false, 'debug' => $debugInfo];
        }
        
        // 检查是否有DMCA错误
        if (DmcaBypasser::hasDmcaError($decodedResponse)) {
            $debugInfo['message'] = "DMCA错误";
            return ['success' => false, 'debug' => $debugInfo];
        }

        // 增强的URL字段检测 - 尝试多个可能的字段名
        $possibleFields = ['url', 'm3u8', 'play_url', 'src', 'address'];
        $foundUrl = null;
        foreach ($possibleFields as $field) {
            if (isset($decodedResponse[$field]) && !empty($decodedResponse[$field])) {
                $foundUrl = $decodedResponse[$field];
                break;
            }
        }

        if ($foundUrl === null) {
            $debugInfo['message'] = "未找到有效URL字段";
            return ['success' => false, 'debug' => $debugInfo];
        }

        // 成功获取到URL
        $debugInfo['success'] = true;
        $debugInfo['message'] = "成功解析";
        $debugInfo['parsed_url'] = $foundUrl;
        
        return [
            'success' => true,
            'parsed_url' => $foundUrl,
            'response' => $decodedResponse,
            'debug' => $debugInfo
        ];
    }
}