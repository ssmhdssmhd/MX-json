<?php
/**
 * 日志记录模块 - 记录系统运行日志和API调用统计
 */

class Logger {
    
    // 日志级别常量
    const LEVEL_DEBUG = 'DEBUG';
    const LEVEL_INFO = 'INFO';
    const LEVEL_WARN = 'WARN';
    const LEVEL_ERROR = 'ERROR';
    
    // 日志文件路径
    private static $logFile = 'logs/system.log';
    private static $apiStatsFile = 'logs/api_stats.json';
    
    /**
     * 初始化日志模块
     */
    public static function init() {
        // 创建日志目录
        if (!file_exists('logs')) {
            mkdir('logs', 0777, true);
        }
        
        // 初始化API统计文件
        if (!file_exists(self::$apiStatsFile)) {
            file_put_contents(self::$apiStatsFile, json_encode([]));
        }
    }
    
    /**
     * 记录日志
     * @param string $message 日志消息
     * @param string $level 日志级别
     * @param array $context 上下文信息
     */
    public static function log($message, $level = self::LEVEL_INFO, $context = []) {
        // 如果未开启调试模式且为DEBUG级别，则不记录
        if (!DEBUG_MODE && $level === self::LEVEL_DEBUG) {
            return;
        }
        
        $timestamp = date('Y-m-d H:i:s');
        $logEntry = "[$timestamp] [$level] $message";
        
        // 添加上下文信息
        if (!empty($context)) {
            $logEntry .= " " . json_encode($context, JSON_UNESCAPED_UNICODE);
        }
        
        $logEntry .= PHP_EOL;
        
        // 写入日志文件
        file_put_contents(self::$logFile, $logEntry, FILE_APPEND | LOCK_EX);
    }
    
    /**
     * 记录API调用统计
     * @param string $api API地址
     * @param bool $success 是否成功
     * @param float $responseTime 响应时间（秒）
     */
    public static function logApiCall($api, $success, $responseTime = 0) {
        $stats = self::getApiStats();
        
        if (!isset($stats[$api])) {
            $stats[$api] = [
                'total_calls' => 0,
                'success_calls' => 0,
                'total_response_time' => 0,
                'last_call' => null
            ];
        }
        
        $stats[$api]['total_calls']++;
        $stats[$api]['total_response_time'] += $responseTime;
        $stats[$api]['last_call'] = date('Y-m-d H:i:s');
        
        if ($success) {
            $stats[$api]['success_calls']++;
        }
        
        // 计算成功率和平均响应时间
        $stats[$api]['success_rate'] = $stats[$api]['total_calls'] > 0 
            ? round(($stats[$api]['success_calls'] / $stats[$api]['total_calls']) * 100, 2) 
            : 0;
            
        $stats[$api]['avg_response_time'] = $stats[$api]['total_calls'] > 0 
            ? round($stats[$api]['total_response_time'] / $stats[$api]['total_calls'], 3) 
            : 0;
        
        file_put_contents(self::$apiStatsFile, json_encode($stats, JSON_PRETTY_PRINT));
    }
    
    /**
     * 获取API统计信息
     * @return array API统计信息
     */
    public static function getApiStats() {
        if (file_exists(self::$apiStatsFile)) {
            return json_decode(file_get_contents(self::$apiStatsFile), true) ?: [];
        }
        return [];
    }
    
    /**
     * 获取指定API的统计信息
     * @param string $api API地址
     * @return array|null API统计信息或null
     */
    public static function getApiStat($api) {
        $stats = self::getApiStats();
        return isset($stats[$api]) ? $stats[$api] : null;
    }
    
    /**
     * 清空API统计信息
     */
    public static function clearApiStats() {
        file_put_contents(self::$apiStatsFile, json_encode([]));
    }
    
    /**
     * 记录调试信息
     * @param string $message 调试消息
     * @param array $context 上下文信息
     */
    public static function debug($message, $context = []) {
        self::log($message, self::LEVEL_DEBUG, $context);
    }
    
    /**
     * 记录一般信息
     * @param string $message 信息消息
     * @param array $context 上下文信息
     */
    public static function info($message, $context = []) {
        self::log($message, self::LEVEL_INFO, $context);
    }
    
    /**
     * 记录警告信息
     * @param string $message 警告消息
     * @param array $context 上下文信息
     */
    public static function warn($message, $context = []) {
        self::log($message, self::LEVEL_WARN, $context);
    }
    
    /**
     * 记录错误信息
     * @param string $message 错误消息
     * @param array $context 上下文信息
     */
    public static function error($message, $context = []) {
        self::log($message, self::LEVEL_ERROR, $context);
    }
}