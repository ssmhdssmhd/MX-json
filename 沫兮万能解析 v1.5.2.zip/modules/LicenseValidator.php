<?php
/**
 * 许可证验证模块
 */

class LicenseValidator {
    /**
     * 验证许可证密钥
     * @return bool 验证是否通过
     */
    public static function validate() {
        if (!LICENSE_ENABLED) {
            return true; // 许可证验证未启用，直接通过
        }
        
        // 检查许可证文件是否存在
        if (!file_exists(LICENSE_FILE)) {
            return false;
        }
        
        // 读取许可证文件内容
        $licenseContent = file_get_contents(LICENSE_FILE);
        if ($licenseContent === false) {
            return false;
        }
        
        // 清理许可证内容（去除空格、换行等）
        $licenseKey = trim($licenseContent);
        
        // 比较配置中的密钥和许可证文件中的密钥
        return $licenseKey === LICENSE_KEY;
    }
    
    /**
     * 获取验证失败的响应
     * @return array 错误响应数组
     */
    public static function getErrorResponse() {
        return [
            'code' => 403,
            'msg' => '授权验证失败，请联系授权',
            'license_enabled' => LICENSE_ENABLED,
            'license_file' => LICENSE_FILE
        ];
    }
}