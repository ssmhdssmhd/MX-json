<?php
/**
 * 限流与频率控制模块 - 防止API滥用
 */

class RateLimiter {
    
    // 限流数据文件
    private static $rateLimitFile = 'logs/rate_limit.json';
    
    // 默认限制规则
    private static $defaultRules = [
        'max_requests_per_minute' => 60,    // 每分钟最大请求数
        'max_requests_per_hour' => 1000,    // 每小时最大请求数
        'max_requests_per_day' => 5000,     // 每天最大请求数
        'ban_duration' => 3600,             // 违规封禁时长(秒)
    ];
    
    // 白名单和黑名单文件
    private static $whitelistFile = 'logs/whitelist.txt';
    private static $blacklistFile = 'logs/blacklist.txt';
    
    /**
     * 初始化限流模块
     */
    public static function init() {
        // 创建日志目录
        if (!file_exists('logs')) {
            mkdir('logs', 0777, true);
        }
        
        // 初始化限流数据文件
        if (!file_exists(self::$rateLimitFile)) {
            file_put_contents(self::$rateLimitFile, json_encode([]));
        }
        
        // 初始化白名单和黑名单文件
        if (!file_exists(self::$whitelistFile)) {
            file_put_contents(self::$whitelistFile, "");
        }
        
        if (!file_exists(self::$blacklistFile)) {
            file_put_contents(self::$blacklistFile, "");
        }
    }
    
    /**
     * 检查请求是否被允许
     * @param string $ip 客户端IP
     * @return array [是否允许, 错误信息]
     */
    public static function checkRequest($ip) {
        // 检查IP是否在白名单中
        if (self::isWhitelisted($ip)) {
            return [true, null];
        }
        
        // 检查IP是否在黑名单中
        if (self::isBlacklisted($ip)) {
            return [false, "IP已被封禁"];
        }
        
        // 获取当前限流规则
        $rules = self::getRules();
        
        // 获取IP的请求历史
        $requestHistory = self::getRequestHistory($ip);
        
        // 检查各种时间段的限制
        $currentTime = time();
        
        // 检查每分钟限制
        $minuteRequests = array_filter($requestHistory, function($time) use ($currentTime) {
            return $time >= $currentTime - 60;
        });
        
        if (count($minuteRequests) >= $rules['max_requests_per_minute']) {
            self::addToBlacklist($ip, "每分钟请求过多");
            return [false, "请求过于频繁，请稍后再试"];
        }
        
        // 检查每小时限制
        $hourRequests = array_filter($requestHistory, function($time) use ($currentTime) {
            return $time >= $currentTime - 3600;
        });
        
        if (count($hourRequests) >= $rules['max_requests_per_hour']) {
            self::addToBlacklist($ip, "每小时请求过多");
            return [false, "每小时请求超过限制"];
        }
        
        // 检查每天限制
        $dayRequests = array_filter($requestHistory, function($time) use ($currentTime) {
            return $time >= $currentTime - 86400;
        });
        
        if (count($dayRequests) >= $rules['max_requests_per_day']) {
            self::addToBlacklist($ip, "每天请求过多");
            return [false, "每天请求超过限制"];
        }
        
        // 记录本次请求
        self::recordRequest($ip);
        
        return [true, null];
    }
    
    /**
     * 记录请求
     * @param string $ip 客户端IP
     */
    private static function recordRequest($ip) {
        $data = self::getRateLimitData();
        $currentTime = time();
        
        if (!isset($data[$ip])) {
            $data[$ip] = [];
        }
        
        // 添加当前时间戳到请求历史
        $data[$ip][] = $currentTime;
        
        // 清理过期的请求记录(保留最近7天的记录)
        $data[$ip] = array_filter($data[$ip], function($time) use ($currentTime) {
            return $time >= $currentTime - 604800; // 7天
        });
        
        // 重新索引数组
        $data[$ip] = array_values($data[$ip]);
        
        self::saveRateLimitData($data);
    }
    
    /**
     * 获取IP的请求历史
     * @param string $ip 客户端IP
     * @return array 请求时间戳数组
     */
    private static function getRequestHistory($ip) {
        $data = self::getRateLimitData();
        return isset($data[$ip]) ? $data[$ip] : [];
    }
    
    /**
     * 获取限流数据
     * @return array 限流数据
     */
    private static function getRateLimitData() {
        if (file_exists(self::$rateLimitFile)) {
            return json_decode(file_get_contents(self::$rateLimitFile), true) ?: [];
        }
        return [];
    }
    
    /**
     * 保存限流数据
     * @param array $data 限流数据
     */
    private static function saveRateLimitData($data) {
        file_put_contents(self::$rateLimitFile, json_encode($data, JSON_PRETTY_PRINT));
    }
    
    /**
     * 获取限流规则
     * @return array 限流规则
     */
    public static function getRules() {
        // 这里可以扩展为从配置文件读取规则
        return self::$defaultRules;
    }
    
    /**
     * 设置限流规则
     * @param array $rules 限流规则
     */
    public static function setRules($rules) {
        // 合并默认规则和自定义规则
        self::$defaultRules = array_merge(self::$defaultRules, $rules);
    }
    
    /**
     * 检查IP是否在白名单中
     * @param string $ip 客户端IP
     * @return bool 是否在白名单中
     */
    public static function isWhitelisted($ip) {
        $whitelist = file(self::$whitelistFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        return in_array($ip, $whitelist);
    }
    
    /**
     * 检查IP是否在黑名单中
     * @param string $ip 客户端IP
     * @return bool 是否在黑名单中
     */
    public static function isBlacklisted($ip) {
        $blacklist = file(self::$blacklistFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        
        foreach ($blacklist as $entry) {
            list($bannedIp, $expiry) = explode('|', $entry);
            if ($bannedIp === $ip) {
                // 检查封禁是否已过期
                if ($expiry > time()) {
                    return true;
                } else {
                    // 封禁已过期，从黑名单中移除
                    self::removeFromBlacklist($ip);
                    return false;
                }
            }
        }
        
        return false;
    }
    
    /**
     * 添加IP到黑名单
     * @param string $ip 客户端IP
     * @param string $reason 封禁原因
     */
    public static function addToBlacklist($ip, $reason = "") {
        $rules = self::getRules();
        $expiry = time() + $rules['ban_duration'];
        
        $entry = "$ip|$expiry|$reason";
        
        file_put_contents(self::$blacklistFile, $entry . PHP_EOL, FILE_APPEND);
        
        // 记录日志
        Logger::warn("IP被封禁", [
            'ip' => $ip,
            'reason' => $reason,
            'expiry' => date('Y-m-d H:i:s', $expiry)
        ]);
    }
    
    /**
     * 从黑名单中移除IP
     * @param string $ip 客户端IP
     */
    public static function removeFromBlacklist($ip) {
        $blacklist = file(self::$blacklistFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        $newBlacklist = [];
        
        foreach ($blacklist as $entry) {
            list($bannedIp) = explode('|', $entry);
            if ($bannedIp !== $ip) {
                $newBlacklist[] = $entry;
            }
        }
        
        file_put_contents(self::$blacklistFile, implode(PHP_EOL, $newBlacklist));
    }
    
    /**
     * 添加IP到白名单
     * @param string $ip 客户端IP
     */
    public static function addToWhitelist($ip) {
        file_put_contents(self::$whitelistFile, $ip . PHP_EOL, FILE_APPEND);
    }
    
    /**
     * 从白名单中移除IP
     * @param string $ip 客户端IP
     */
    public static function removeFromWhitelist($ip) {
        $whitelist = file(self::$whitelistFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        $newWhitelist = array_filter($whitelist, function($entry) use ($ip) {
            return $entry !== $ip;
        });
        
        file_put_contents(self::$whitelistFile, implode(PHP_EOL, $newWhitelist));
    }
    
    /**
     * 清理过期的黑名单条目
     */
    public static function cleanupExpiredBans() {
        $blacklist = file(self::$blacklistFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        $newBlacklist = [];
        $currentTime = time();
        
        foreach ($blacklist as $entry) {
            list($ip, $expiry) = explode('|', $entry);
            if ($expiry > $currentTime) {
                $newBlacklist[] = $entry;
            }
        }
        
        file_put_contents(self::$blacklistFile, implode(PHP_EOL, $newBlacklist));
    }
    
    /**
     * 获取限流统计信息
     * @return array 统计信息
     */
    public static function getStats() {
        $data = self::getRateLimitData();
        $stats = [
            'total_ips' => count($data),
            'total_requests' => 0,
            'active_ips' => 0
        ];
        
        $currentTime = time();
        $oneHourAgo = $currentTime - 3600;
        
        foreach ($data as $ip => $requests) {
            $stats['total_requests'] += count($requests);
            
            // 检查最近一小时是否有活动
            $recentRequests = array_filter($requests, function($time) use ($oneHourAgo) {
                return $time >= $oneHourAgo;
            });
            
            if (!empty($recentRequests)) {
                $stats['active_ips']++;
            }
        }
        
        return $stats;
    }
}